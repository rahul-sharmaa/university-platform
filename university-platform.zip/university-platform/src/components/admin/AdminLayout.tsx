"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  GraduationCap,
  Users,
  FileText,
  ClipboardList,
  History,
  Upload,
  LogOut,
  GraduationCap as Logo,
} from "lucide-react";

interface AdminLayoutProps {
  children: React.ReactNode;
  user: { name: string; email: string; role: string };
}

const navItems = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard, roles: ["SUPER_ADMIN", "UNIVERSITY_ADMIN"] },
  { href: "/admin/universities", label: "Universities", icon: GraduationCap, roles: ["SUPER_ADMIN", "UNIVERSITY_ADMIN"] },
  { href: "/admin/leads", label: "Leads", icon: FileText, roles: ["SUPER_ADMIN", "UNIVERSITY_ADMIN"] },
  { href: "/admin/revisions", label: "Pending Reviews", icon: ClipboardList, roles: ["SUPER_ADMIN"] },
  { href: "/admin/users", label: "Users", icon: Users, roles: ["SUPER_ADMIN"] },
  { href: "/admin/audit-log", label: "Audit Log", icon: History, roles: ["SUPER_ADMIN"] },
  { href: "/admin/import", label: "Import", icon: Upload, roles: ["SUPER_ADMIN"] },
];

export function AdminLayout({ children, user }: AdminLayoutProps) {
  const pathname = usePathname();

  const visibleNav = navItems.filter((item) =>
    item.roles.includes(user.role)
  );

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r bg-white">
        <div className="flex h-16 items-center gap-2 border-b px-6">
          <Logo className="h-6 w-6 text-primary" />
          <span className="text-lg font-bold">
            UniRank <span className="text-xs text-gray-400">Admin</span>
          </span>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4">
          <ul className="space-y-1">
            {visibleNav.map((item) => {
              const Icon = item.icon;
              const isActive =
                pathname === item.href ||
                (item.href !== "/admin" && pathname.startsWith(item.href));

              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                      isActive
                        ? "bg-primary/10 text-primary"
                        : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="border-t p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
              {user.name.charAt(0)}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-gray-900">
                {user.name}
              </p>
              <p className="truncate text-xs text-gray-500">{user.role.replace("_", " ")}</p>
            </div>
          </div>
          <form action="/api/auth/signout" method="post" className="mt-3">
            <button
              type="submit"
              className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-600 hover:bg-gray-100"
            >
              <LogOut className="h-4 w-4" />
              Sign out
            </button>
          </form>
        </div>
      </aside>

      {/* Main content */}
      <main className="ml-64 flex-1 p-8">{children}</main>
    </div>
  );
}
