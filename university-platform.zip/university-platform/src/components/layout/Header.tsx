"use client";

import Link from "next/link";
import { useState } from "react";
import { Search, Menu, X, GraduationCap } from "lucide-react";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <GraduationCap className="h-8 w-8 text-primary" />
          <span className="text-xl font-bold text-gray-900">
            UniRank <span className="text-primary">India</span>
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <Link
            href="/universities"
            className="text-sm font-medium text-gray-600 hover:text-primary transition-colors"
          >
            Universities
          </Link>
          <Link
            href="/rankings/nirf"
            className="text-sm font-medium text-gray-600 hover:text-primary transition-colors"
          >
            Rankings
          </Link>
          <Link
            href="/courses/engineering"
            className="text-sm font-medium text-gray-600 hover:text-primary transition-colors"
          >
            Courses
          </Link>
          <Link
            href="/compare"
            className="text-sm font-medium text-gray-600 hover:text-primary transition-colors"
          >
            Compare
          </Link>
        </nav>

        {/* Search + CTA */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className="rounded-full p-2 text-gray-500 hover:bg-gray-100 transition-colors"
            aria-label="Search"
          >
            <Search className="h-5 w-5" />
          </button>

          <Link
            href="/apply"
            className="hidden sm:inline-flex items-center rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white hover:bg-primary/90 transition-colors"
          >
            Apply Now
          </Link>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden rounded-full p-2 text-gray-500 hover:bg-gray-100"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? (
              <X className="h-5 w-5" />
            ) : (
              <Menu className="h-5 w-5" />
            )}
          </button>
        </div>
      </div>

      {/* Search bar dropdown */}
      {searchOpen && (
        <div className="border-t bg-white px-4 py-3">
          <div className="mx-auto max-w-2xl">
            <form action="/universities" method="get">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  name="q"
                  placeholder="Search universities, courses, cities..."
                  className="w-full rounded-lg border bg-gray-50 py-2.5 pl-10 pr-4 text-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                  autoFocus
                />
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <nav className="border-t bg-white px-4 py-4 md:hidden">
          <div className="flex flex-col gap-3">
            <Link href="/universities" className="text-sm font-medium text-gray-700 py-2">
              Universities
            </Link>
            <Link href="/rankings/nirf" className="text-sm font-medium text-gray-700 py-2">
              Rankings
            </Link>
            <Link href="/courses/engineering" className="text-sm font-medium text-gray-700 py-2">
              Courses
            </Link>
            <Link href="/compare" className="text-sm font-medium text-gray-700 py-2">
              Compare
            </Link>
            <Link
              href="/apply"
              className="mt-2 inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-white"
            >
              Apply Now
            </Link>
          </div>
        </nav>
      )}
    </header>
  );
}
