import Link from "next/link";
import { GraduationCap } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t bg-gray-50">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <Link href="/" className="flex items-center gap-2">
              <GraduationCap className="h-6 w-6 text-primary" />
              <span className="text-lg font-bold">UniRank India</span>
            </Link>
            <p className="mt-3 text-sm text-gray-500">
              Discover and compare India&apos;s top universities. Find the right
              institution for your academic journey.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900">Explore</h3>
            <ul className="mt-3 space-y-2">
              <li>
                <Link href="/universities" className="text-sm text-gray-500 hover:text-primary">
                  All Universities
                </Link>
              </li>
              <li>
                <Link href="/rankings/nirf" className="text-sm text-gray-500 hover:text-primary">
                  NIRF Rankings
                </Link>
              </li>
              <li>
                <Link href="/rankings/qs" className="text-sm text-gray-500 hover:text-primary">
                  QS Rankings
                </Link>
              </li>
              <li>
                <Link href="/compare" className="text-sm text-gray-500 hover:text-primary">
                  Compare
                </Link>
              </li>
            </ul>
          </div>

          {/* Browse by */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900">Browse By</h3>
            <ul className="mt-3 space-y-2">
              <li>
                <Link href="/states/maharashtra" className="text-sm text-gray-500 hover:text-primary">
                  Maharashtra
                </Link>
              </li>
              <li>
                <Link href="/states/karnataka" className="text-sm text-gray-500 hover:text-primary">
                  Karnataka
                </Link>
              </li>
              <li>
                <Link href="/states/delhi" className="text-sm text-gray-500 hover:text-primary">
                  Delhi
                </Link>
              </li>
              <li>
                <Link href="/courses/engineering" className="text-sm text-gray-500 hover:text-primary">
                  Engineering
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900">Company</h3>
            <ul className="mt-3 space-y-2">
              <li>
                <Link href="/about" className="text-sm text-gray-500 hover:text-primary">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-sm text-gray-500 hover:text-primary">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-sm text-gray-500 hover:text-primary">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-sm text-gray-500 hover:text-primary">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t pt-6">
          <p className="text-center text-xs text-gray-400">
            &copy; {new Date().getFullYear()} UniRank India. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
