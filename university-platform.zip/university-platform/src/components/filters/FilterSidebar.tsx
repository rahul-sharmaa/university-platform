"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback } from "react";
import { getNaacLabel, getUniversityTypeLabel } from "@/lib/utils";

interface FilterOption {
  value: string;
  label: string;
  count?: number;
}

interface FilterSidebarProps {
  states: FilterOption[];
  universityTypes: FilterOption[];
  naacGrades: FilterOption[];
}

export function FilterSidebar({
  states,
  universityTypes,
  naacGrades,
}: FilterSidebarProps) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const updateFilter = useCallback(
    (key: string, value: string) => {
      const params = new URLSearchParams(searchParams.toString());
      if (params.get(key) === value) {
        params.delete(key);
      } else {
        params.set(key, value);
      }
      params.set("page", "1");
      router.push(`/universities?${params.toString()}`);
    },
    [router, searchParams]
  );

  const clearFilters = useCallback(() => {
    router.push("/universities");
  }, [router]);

  const hasFilters = searchParams.toString().length > 0;

  return (
    <aside className="w-full lg:w-64 shrink-0">
      <div className="rounded-xl border bg-white p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-gray-900">Filters</h2>
          {hasFilters && (
            <button
              onClick={clearFilters}
              className="text-xs text-primary hover:underline"
            >
              Clear all
            </button>
          )}
        </div>

        {/* State filter */}
        <div className="mt-5">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-500">
            State
          </h3>
          <div className="mt-2 max-h-40 space-y-1.5 overflow-y-auto">
            {states.map((state) => (
              <button
                key={state.value}
                onClick={() => updateFilter("state", state.value)}
                className={`flex w-full items-center justify-between rounded-md px-2 py-1.5 text-left text-sm transition-colors ${
                  searchParams.get("state") === state.value
                    ? "bg-primary/10 text-primary font-medium"
                    : "text-gray-600 hover:bg-gray-50"
                }`}
              >
                <span>{state.label}</span>
                {state.count != null && (
                  <span className="text-xs text-gray-400">{state.count}</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* University Type filter */}
        <div className="mt-5">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-500">
            University Type
          </h3>
          <div className="mt-2 space-y-1.5">
            {universityTypes.map((type) => (
              <button
                key={type.value}
                onClick={() => updateFilter("universityType", type.value)}
                className={`flex w-full items-center justify-between rounded-md px-2 py-1.5 text-left text-sm transition-colors ${
                  searchParams.get("universityType") === type.value
                    ? "bg-primary/10 text-primary font-medium"
                    : "text-gray-600 hover:bg-gray-50"
                }`}
              >
                <span>{type.label}</span>
                {type.count != null && (
                  <span className="text-xs text-gray-400">{type.count}</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* NAAC Grade filter */}
        <div className="mt-5">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-500">
            NAAC Grade
          </h3>
          <div className="mt-2 space-y-1.5">
            {naacGrades.map((grade) => (
              <button
                key={grade.value}
                onClick={() => updateFilter("naacGrade", grade.value)}
                className={`flex w-full items-center justify-between rounded-md px-2 py-1.5 text-left text-sm transition-colors ${
                  searchParams.get("naacGrade") === grade.value
                    ? "bg-primary/10 text-primary font-medium"
                    : "text-gray-600 hover:bg-gray-50"
                }`}
              >
                <span>{grade.label}</span>
                {grade.count != null && (
                  <span className="text-xs text-gray-400">{grade.count}</span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
}
