import Link from "next/link";
import { MapPin, Award, Calendar, BookOpen } from "lucide-react";
import { formatCurrency, formatRank, getNaacLabel, getUniversityTypeLabel } from "@/lib/utils";
import type { UniversityCard as UniversityCardType } from "@/types";

interface UniversityCardProps {
  university: UniversityCardType;
}

export function UniversityCard({ university }: UniversityCardProps) {
  const bestRank =
    university.nirfRank ?? university.qsRank ?? university.theRank;
  const bestRankLabel = university.nirfRank
    ? "NIRF"
    : university.qsRank
      ? "QS"
      : university.theRank
        ? "THE"
        : null;

  return (
    <div className="group relative rounded-xl border bg-white p-5 shadow-sm hover:shadow-md transition-all duration-200">
      {/* Featured/Trending badges */}
      {(university.isFeatured || university.isTrending) && (
        <div className="absolute -top-2 right-4 flex gap-1">
          {university.isFeatured && (
            <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-700">
              Featured
            </span>
          )}
          {university.isTrending && (
            <span className="rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-semibold text-green-700">
              Trending
            </span>
          )}
        </div>
      )}

      {/* Header row: logo + name + location */}
      <div className="flex items-start gap-4">
        <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-primary">
          {university.logoUrl ? (
            <img
              src={university.logoUrl}
              alt={`${university.name} logo`}
              className="h-12 w-12 rounded-lg object-contain"
            />
          ) : (
            <BookOpen className="h-7 w-7" />
          )}
        </div>

        <div className="min-w-0 flex-1">
          <Link href={`/universities/${university.slug}`}>
            <h3 className="text-base font-semibold text-gray-900 group-hover:text-primary transition-colors line-clamp-2">
              {university.name}
            </h3>
          </Link>
          <div className="mt-1 flex items-center gap-1 text-sm text-gray-500">
            <MapPin className="h-3.5 w-3.5" />
            <span>
              {university.city.name}, {university.state.name}
            </span>
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div className="mt-4 flex flex-wrap items-center gap-3">
        {bestRank && bestRankLabel && (
          <span className="inline-flex items-center gap-1 rounded-md bg-blue-50 px-2 py-1 text-xs font-semibold text-blue-700">
            <Award className="h-3 w-3" />
            {bestRankLabel} {formatRank(bestRank)}
          </span>
        )}
        {university.naacGrade !== "NOT_ACCREDITED" && (
          <span className="rounded-md bg-purple-50 px-2 py-1 text-xs font-semibold text-purple-700">
            NAAC {getNaacLabel(university.naacGrade)}
          </span>
        )}
        {university.establishedYear && (
          <span className="inline-flex items-center gap-1 text-xs text-gray-500">
            <Calendar className="h-3 w-3" />
            Est. {university.establishedYear}
          </span>
        )}
        <span className="rounded-md bg-gray-100 px-2 py-1 text-xs font-medium text-gray-600">
          {getUniversityTypeLabel(university.universityType)}
        </span>
      </div>

      {/* Courses + Fees */}
      <div className="mt-3 flex items-center justify-between text-sm">
        {university._count?.courses ? (
          <span className="text-gray-500">
            {university._count.courses} courses
          </span>
        ) : (
          <span />
        )}
        {(university.feesMin || university.feesMax) && (
          <span className="text-gray-600 font-medium">
            {formatCurrency(Number(university.feesMin))} –{" "}
            {formatCurrency(Number(university.feesMax))}/yr
          </span>
        )}
      </div>

      {/* Action buttons */}
      <div className="mt-4 flex items-center gap-2">
        <Link
          href={`/apply?university=${university.id}`}
          className="flex-1 rounded-lg bg-primary py-2 text-center text-sm font-semibold text-white hover:bg-primary/90 transition-colors"
        >
          Apply Now
        </Link>
        <Link
          href={`/universities/${university.slug}`}
          className="flex-1 rounded-lg border border-gray-200 py-2 text-center text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
        >
          View Details
        </Link>
      </div>
    </div>
  );
}
