import { UserRole } from "@prisma/client";

export type Permission =
  | "university:create"
  | "university:read:all"
  | "university:read:own"
  | "university:update:all"
  | "university:update:own"
  | "university:delete"
  | "university:approve"
  | "lead:read:all"
  | "lead:read:own"
  | "lead:update:all"
  | "lead:update:own"
  | "user:manage"
  | "audit:read"
  | "import:execute";

const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  SUPER_ADMIN: [
    "university:create",
    "university:read:all",
    "university:update:all",
    "university:delete",
    "university:approve",
    "lead:read:all",
    "lead:update:all",
    "user:manage",
    "audit:read",
    "import:execute",
  ],
  UNIVERSITY_ADMIN: [
    "university:read:own",
    "university:update:own",
    "lead:read:own",
    "lead:update:own",
  ],
};

export function hasPermission(role: UserRole, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
}

export function getPermissions(role: UserRole): Permission[] {
  return ROLE_PERMISSIONS[role] ?? [];
}
