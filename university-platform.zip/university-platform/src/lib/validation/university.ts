import { z } from "zod";

export const universityFilterSchema = z.object({
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(100).default(20),
  sort: z
    .enum([
      "nirf_rank",
      "qs_rank",
      "the_rank",
      "name",
      "established_year",
      "fees_min",
    ])
    .default("nirf_rank"),
  order: z.enum(["asc", "desc"]).default("asc"),
  state: z.string().optional(),
  city: z.string().optional(),
  courseCategory: z.string().optional(),
  universityType: z
    .enum(["CENTRAL", "STATE", "PRIVATE", "DEEMED", "IIT", "NIT", "IIIT", "OTHER"])
    .optional(),
  naacGrade: z.string().optional(),
  nbaStatus: z.enum(["ACCREDITED", "NOT_ACCREDITED", "APPLIED"]).optional(),
  feesMin: z.coerce.number().optional(),
  feesMax: z.coerce.number().optional(),
  establishedBefore: z.coerce.number().optional(),
  q: z.string().max(200).optional(),
});

export type UniversityFilterParams = z.infer<typeof universityFilterSchema>;

export const universityCreateSchema = z.object({
  name: z.string().min(2).max(500),
  slug: z
    .string()
    .min(2)
    .max(500)
    .regex(/^[a-z0-9-]+$/, "Slug must be lowercase with hyphens only"),
  shortName: z.string().max(100).optional(),
  stateId: z.number(),
  cityId: z.number(),
  address: z.string().optional(),
  description: z.string().optional(),
  website: z.string().url().optional().or(z.literal("")),
  establishedYear: z.number().min(1800).max(2030).optional(),
  universityType: z
    .enum(["CENTRAL", "STATE", "PRIVATE", "DEEMED", "IIT", "NIT", "IIIT", "OTHER"])
    .default("OTHER"),
  qsRank: z.number().min(1).optional().nullable(),
  theRank: z.number().min(1).optional().nullable(),
  nirfRank: z.number().min(1).optional().nullable(),
  naacGrade: z
    .enum([
      "A_PLUS_PLUS",
      "A_PLUS",
      "A",
      "B_PLUS_PLUS",
      "B_PLUS",
      "B",
      "C",
      "NOT_ACCREDITED",
    ])
    .default("NOT_ACCREDITED"),
  nbaStatus: z
    .enum(["ACCREDITED", "NOT_ACCREDITED", "APPLIED"])
    .default("NOT_ACCREDITED"),
  feesMin: z.number().optional().nullable(),
  feesMax: z.number().optional().nullable(),
  avgPlacementLpa: z.number().optional().nullable(),
  highestPlacementLpa: z.number().optional().nullable(),
  placementRate: z.number().min(0).max(100).optional().nullable(),
  contactEmail: z.string().email().optional().or(z.literal("")),
  contactPhone: z.string().optional(),
  status: z
    .enum(["DRAFT", "PENDING_REVIEW", "PUBLISHED", "ARCHIVED"])
    .default("DRAFT"),
  isFeatured: z.boolean().default(false),
  isTrending: z.boolean().default(false),
  metaTitle: z.string().max(160).optional(),
  metaDescription: z.string().max(320).optional(),
});

export type UniversityCreateData = z.infer<typeof universityCreateSchema>;
