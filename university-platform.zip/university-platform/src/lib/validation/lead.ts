import { z } from "zod";

export const leadFormSchema = z.object({
  name: z
    .string()
    .min(2, "Name must be at least 2 characters")
    .max(255),
  email: z.string().email("Please enter a valid email address"),
  phone: z
    .string()
    .regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit Indian mobile number"),
  interestedCourse: z.string().max(300).optional(),
  universityId: z.string().optional(),
  state: z.string().max(100).optional(),
  city: z.string().max(100).optional(),
  message: z.string().max(1000).optional(),
});

export type LeadFormData = z.infer<typeof leadFormSchema>;
