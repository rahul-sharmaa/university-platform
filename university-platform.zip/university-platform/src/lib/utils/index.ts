import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number | null | undefined): string {
  if (amount == null) return "N/A";
  if (amount >= 10000000) {
    return `₹${(amount / 10000000).toFixed(1)}Cr`;
  }
  if (amount >= 100000) {
    return `₹${(amount / 100000).toFixed(1)}L`;
  }
  return `₹${amount.toLocaleString("en-IN")}`;
}

export function formatRank(rank: number | null | undefined): string {
  if (rank == null) return "N/A";
  return `#${rank}`;
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function getNaacLabel(grade: string): string {
  const map: Record<string, string> = {
    A_PLUS_PLUS: "A++",
    A_PLUS: "A+",
    A: "A",
    B_PLUS_PLUS: "B++",
    B_PLUS: "B+",
    B: "B",
    C: "C",
    NOT_ACCREDITED: "Not Accredited",
  };
  return map[grade] ?? grade;
}

export function getUniversityTypeLabel(type: string): string {
  const map: Record<string, string> = {
    CENTRAL: "Central University",
    STATE: "State University",
    PRIVATE: "Private University",
    DEEMED: "Deemed University",
    IIT: "IIT",
    NIT: "NIT",
    IIIT: "IIIT",
    OTHER: "Other",
  };
  return map[type] ?? type;
}

export function truncate(text: string, length: number): string {
  if (text.length <= length) return text;
  return text.slice(0, length).trimEnd() + "...";
}
