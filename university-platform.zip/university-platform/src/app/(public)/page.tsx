import Link from "next/link";
import { db } from "@/lib/db";
import { UniversityCard } from "@/components/university/UniversityCard";
import { Search, TrendingUp, Award, MapPin, BookOpen } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "UniRank India — Discover Top Universities in India 2025",
  description:
    "Browse India's top-ranked universities. Compare NIRF, QS, and THE rankings. Explore courses, fees, placements, and apply directly.",
};

export const revalidate = 60;

export default async function HomePage() {
  const [featured, trending, states, totalCount] = await Promise.all([
    db.university.findMany({
      where: { status: "PUBLISHED", isFeatured: true },
      include: {
        state: true,
        city: true,
        _count: { select: { courses: true } },
      },
      orderBy: { nirfRank: "asc" },
      take: 6,
    }),
    db.university.findMany({
      where: { status: "PUBLISHED", isTrending: true },
      include: {
        state: true,
        city: true,
        _count: { select: { courses: true } },
      },
      take: 4,
    }),
    db.state.findMany({
      include: { _count: { select: { universities: true } } },
      orderBy: { name: "asc" },
    }),
    db.university.count({ where: { status: "PUBLISHED" } }),
  ]);

  return (
    <>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 py-20 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
              Find Your Perfect University
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-blue-100">
              Explore {totalCount}+ top-ranked universities in India. Compare
              rankings, courses, fees, and apply directly.
            </p>

            {/* Search Bar */}
            <form
              action="/universities"
              method="get"
              className="mx-auto mt-8 max-w-xl"
            >
              <div className="relative">
                <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  name="q"
                  placeholder="Search universities, courses, or cities..."
                  className="w-full rounded-xl border-0 py-4 pl-12 pr-4 text-gray-900 shadow-lg focus:outline-none focus:ring-2 focus:ring-white/50"
                />
              </div>
            </form>

            {/* Quick filters */}
            <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
              {["IIT", "NIT", "IIIT", "CENTRAL", "PRIVATE"].map((type) => (
                <Link
                  key={type}
                  href={`/universities?universityType=${type}`}
                  className="rounded-full bg-white/15 px-4 py-1.5 text-sm font-medium text-white backdrop-blur-sm hover:bg-white/25 transition-colors"
                >
                  {type === "CENTRAL" ? "Central Universities" : `${type}s`}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Universities */}
      {featured.length > 0 && (
        <section className="py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="flex items-center gap-2 text-2xl font-bold text-gray-900">
                  <Award className="h-6 w-6 text-amber-500" />
                  Featured Universities
                </h2>
                <p className="mt-1 text-sm text-gray-500">
                  Top-ranked institutions handpicked for you
                </p>
              </div>
              <Link
                href="/universities"
                className="text-sm font-semibold text-primary hover:underline"
              >
                View All →
              </Link>
            </div>

            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {featured.map((uni) => (
                <UniversityCard key={uni.id} university={uni as any} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Trending Universities */}
      {trending.length > 0 && (
        <section className="bg-gray-50 py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <h2 className="flex items-center gap-2 text-2xl font-bold text-gray-900">
              <TrendingUp className="h-6 w-6 text-green-500" />
              Trending Now
            </h2>
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {trending.map((uni) => (
                <UniversityCard key={uni.id} university={uni as any} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Browse by State */}
      {states.length > 0 && (
        <section className="py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <h2 className="flex items-center gap-2 text-2xl font-bold text-gray-900">
              <MapPin className="h-6 w-6 text-red-500" />
              Browse by State
            </h2>
            <div className="mt-8 grid gap-3 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
              {states
                .filter((s) => s._count.universities > 0)
                .map((state) => (
                  <Link
                    key={state.id}
                    href={`/states/${state.slug}`}
                    className="flex items-center justify-between rounded-lg border bg-white px-4 py-3 hover:border-primary hover:shadow-sm transition-all"
                  >
                    <span className="font-medium text-gray-800">
                      {state.name}
                    </span>
                    <span className="text-sm text-gray-400">
                      {state._count.universities}
                    </span>
                  </Link>
                ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Banner */}
      <section className="bg-gradient-to-r from-primary to-indigo-600 py-16">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <h2 className="text-3xl font-bold text-white">
            Not sure which university is right for you?
          </h2>
          <p className="mt-3 text-lg text-blue-100">
            Submit your details and our expert counselors will guide you to the
            best options based on your goals and profile.
          </p>
          <Link
            href="/apply"
            className="mt-8 inline-flex items-center rounded-lg bg-white px-8 py-3.5 text-base font-semibold text-primary shadow-lg hover:bg-gray-50 transition-colors"
          >
            Get Free Counseling
          </Link>
        </div>
      </section>
    </>
  );
}
