import { db } from "@/lib/db";
import { UniversityCard } from "@/components/university/UniversityCard";
import { FilterSidebar } from "@/components/filters/FilterSidebar";
import { Breadcrumbs } from "@/components/layout/Breadcrumbs";
import { getNaacLabel, getUniversityTypeLabel } from "@/lib/utils";
import type { Metadata } from "next";
import Link from "next/link";
import type { Prisma, UniversityType, NaacGrade, NbaStatus } from "@prisma/client";

export const metadata: Metadata = {
  title: "All Universities in India — Rankings, Courses & Admissions",
  description:
    "Browse and filter India's top universities by state, ranking, course, accreditation, and fees. Find the perfect university for your career.",
};

export const revalidate = 60;

interface PageProps {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}

export default async function UniversitiesListPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const page = Number(params.page) || 1;
  const limit = 20;
  const skip = (page - 1) * limit;
  const query = typeof params.q === "string" ? params.q : undefined;
  const stateSlug = typeof params.state === "string" ? params.state : undefined;
  const universityType = typeof params.universityType === "string" ? params.universityType as UniversityType : undefined;
  const naacGrade = typeof params.naacGrade === "string" ? params.naacGrade as NaacGrade : undefined;
  const sortField = typeof params.sort === "string" ? params.sort : "nirfRank";

  // Build where clause
  const where: Prisma.UniversityWhereInput = {
    status: "PUBLISHED",
    ...(stateSlug && { state: { slug: stateSlug } }),
    ...(universityType && { universityType }),
    ...(naacGrade && { naacGrade }),
    ...(query && {
      OR: [
        { name: { contains: query, mode: "insensitive" } },
        { shortName: { contains: query, mode: "insensitive" } },
        { description: { contains: query, mode: "insensitive" } },
        { city: { name: { contains: query, mode: "insensitive" } } },
        { state: { name: { contains: query, mode: "insensitive" } } },
      ],
    }),
  };

  // Build sort
  const sortMap: Record<string, Prisma.UniversityOrderByWithRelationInput> = {
    nirfRank: { nirfRank: { sort: "asc", nulls: "last" } },
    qsRank: { qsRank: { sort: "asc", nulls: "last" } },
    name: { name: "asc" },
    establishedYear: { establishedYear: { sort: "asc", nulls: "last" } },
    feesMin: { feesMin: { sort: "asc", nulls: "last" } },
  };
  const orderBy = sortMap[sortField] || sortMap.nirfRank;

  const [universities, total, filterStates, filterTypes, filterGrades] =
    await Promise.all([
      db.university.findMany({
        where,
        include: {
          state: true,
          city: true,
          _count: { select: { courses: true } },
        },
        orderBy,
        skip,
        take: limit,
      }),
      db.university.count({ where }),
      db.state.findMany({
        where: { universities: { some: { status: "PUBLISHED" } } },
        include: {
          _count: {
            select: { universities: { where: { status: "PUBLISHED" } } },
          },
        },
        orderBy: { name: "asc" },
      }),
      db.university.groupBy({
        by: ["universityType"],
        where: { status: "PUBLISHED" },
        _count: true,
      }),
      db.university.groupBy({
        by: ["naacGrade"],
        where: { status: "PUBLISHED", naacGrade: { not: "NOT_ACCREDITED" } },
        _count: true,
      }),
    ]);

  const totalPages = Math.ceil(total / limit);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      <Breadcrumbs items={[{ label: "Universities" }]} />

      <h1 className="text-2xl font-bold text-gray-900">
        Universities in India
        {query && (
          <span className="text-gray-500 font-normal">
            {" "}
            — results for &ldquo;{query}&rdquo;
          </span>
        )}
      </h1>
      <p className="mt-1 text-sm text-gray-500">
        {total} {total === 1 ? "university" : "universities"} found
      </p>

      <div className="mt-6 flex flex-col gap-8 lg:flex-row">
        {/* Sidebar */}
        <FilterSidebar
          states={filterStates.map((s) => ({
            value: s.slug,
            label: s.name,
            count: s._count.universities,
          }))}
          universityTypes={filterTypes.map((t) => ({
            value: t.universityType,
            label: getUniversityTypeLabel(t.universityType),
            count: t._count,
          }))}
          naacGrades={filterGrades.map((g) => ({
            value: g.naacGrade,
            label: `NAAC ${getNaacLabel(g.naacGrade)}`,
            count: g._count,
          }))}
        />

        {/* Results */}
        <div className="flex-1">
          {/* Sort controls */}
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-gray-500">
              Sort by:
              {[
                { key: "nirfRank", label: "NIRF Rank" },
                { key: "qsRank", label: "QS Rank" },
                { key: "name", label: "Name" },
                { key: "feesMin", label: "Fees" },
              ].map((s) => (
                <Link
                  key={s.key}
                  href={`/universities?${new URLSearchParams({
                    ...Object.fromEntries(
                      Object.entries(params).filter(([_, v]) => typeof v === "string") as [string, string][]
                    ),
                    sort: s.key,
                    page: "1",
                  }).toString()}`}
                  className={`rounded-md px-2 py-1 transition-colors ${
                    sortField === s.key
                      ? "bg-primary/10 text-primary font-medium"
                      : "hover:bg-gray-100"
                  }`}
                >
                  {s.label}
                </Link>
              ))}
            </div>
          </div>

          {/* University grid */}
          {universities.length > 0 ? (
            <div className="grid gap-6 sm:grid-cols-2">
              {universities.map((uni) => (
                <UniversityCard key={uni.id} university={uni as any} />
              ))}
            </div>
          ) : (
            <div className="rounded-xl border bg-gray-50 py-16 text-center">
              <p className="text-gray-500">
                No universities found matching your criteria.
              </p>
              <Link
                href="/universities"
                className="mt-3 inline-block text-sm font-semibold text-primary hover:underline"
              >
                Clear filters
              </Link>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-8 flex items-center justify-center gap-2">
              {page > 1 && (
                <Link
                  href={`/universities?${new URLSearchParams({
                    ...Object.fromEntries(
                      Object.entries(params).filter(([_, v]) => typeof v === "string") as [string, string][]
                    ),
                    page: String(page - 1),
                  }).toString()}`}
                  className="rounded-lg border px-3 py-2 text-sm hover:bg-gray-50"
                >
                  Previous
                </Link>
              )}
              <span className="text-sm text-gray-500">
                Page {page} of {totalPages}
              </span>
              {page < totalPages && (
                <Link
                  href={`/universities?${new URLSearchParams({
                    ...Object.fromEntries(
                      Object.entries(params).filter(([_, v]) => typeof v === "string") as [string, string][]
                    ),
                    page: String(page + 1),
                  }).toString()}`}
                  className="rounded-lg border px-3 py-2 text-sm hover:bg-gray-50"
                >
                  Next
                </Link>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
