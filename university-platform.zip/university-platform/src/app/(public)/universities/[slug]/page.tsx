import { db } from "@/lib/db";
import { notFound } from "next/navigation";
import { Breadcrumbs } from "@/components/layout/Breadcrumbs";
import { LeadForm } from "@/components/forms/LeadForm";
import {
  formatCurrency,
  formatRank,
  getNaacLabel,
  getUniversityTypeLabel,
} from "@/lib/utils";
import {
  MapPin,
  Globe,
  Calendar,
  Award,
  BookOpen,
  TrendingUp,
  Phone,
  Mail,
  ExternalLink,
} from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const university = await db.university.findUnique({
    where: { slug, status: "PUBLISHED" },
    include: { state: true, city: true },
  });

  if (!university) return { title: "University Not Found" };

  return {
    title: university.metaTitle || `${university.name} — Rankings, Courses, Fees & Admissions`,
    description:
      university.metaDescription ||
      `${university.name} in ${university.city.name}, ${university.state.name}. NIRF Rank ${formatRank(university.nirfRank)}. Courses, fees, placements, and admissions.`,
    openGraph: {
      title: university.name,
      description: university.description?.slice(0, 200) || "",
      images: university.coverImageUrl ? [university.coverImageUrl] : [],
    },
  };
}

export async function generateStaticParams() {
  const universities = await db.university.findMany({
    where: { status: "PUBLISHED" },
    select: { slug: true },
  });
  return universities.map((u) => ({ slug: u.slug }));
}

export const revalidate = 300;

export default async function UniversityDetailPage({ params }: PageProps) {
  const { slug } = await params;

  const university = await db.university.findUnique({
    where: { slug, status: "PUBLISHED" },
    include: {
      state: true,
      city: true,
      courses: { include: { category: true }, where: { isActive: true }, orderBy: { name: "asc" } },
      faqs: { where: { isActive: true }, orderBy: { sortOrder: "asc" } },
    },
  });

  if (!university) notFound();

  // Increment view count (fire and forget)
  db.university
    .update({ where: { id: university.id }, data: { viewCount: { increment: 1 } } })
    .catch(() => {});

  // Schema.org JSON-LD
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollegeOrUniversity",
    name: university.name,
    url: university.website,
    address: {
      "@type": "PostalAddress",
      addressLocality: university.city.name,
      addressRegion: university.state.name,
      addressCountry: "IN",
    },
    foundingDate: university.establishedYear?.toString(),
  };

  const faqJsonLd = university.faqs.length > 0 ? {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: university.faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: { "@type": "Answer", text: faq.answer },
    })),
  } : null;

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      {faqJsonLd && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
        />
      )}

      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <Breadcrumbs
          items={[
            { label: "Universities", href: "/universities" },
            { label: university.state.name, href: `/states/${university.state.slug}` },
            { label: university.name },
          ]}
        />

        {/* Hero Section */}
        <div className="mt-4 rounded-2xl border bg-white p-6 sm:p-8">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-start">
            {/* Logo */}
            <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-xl bg-gray-100">
              {university.logoUrl ? (
                <img src={university.logoUrl} alt="" className="h-16 w-16 object-contain" />
              ) : (
                <BookOpen className="h-10 w-10 text-primary" />
              )}
            </div>

            {/* Info */}
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-900 sm:text-3xl">
                {university.name}
              </h1>
              <div className="mt-2 flex flex-wrap items-center gap-3 text-sm text-gray-500">
                <span className="inline-flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {university.city.name}, {university.state.name}
                </span>
                {university.establishedYear && (
                  <span className="inline-flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    Est. {university.establishedYear}
                  </span>
                )}
                <span className="rounded-md bg-gray-100 px-2 py-0.5 text-xs font-medium">
                  {getUniversityTypeLabel(university.universityType)}
                </span>
              </div>

              {/* Key stats */}
              <div className="mt-4 flex flex-wrap gap-3">
                {university.nirfRank && (
                  <div className="rounded-lg bg-blue-50 px-3 py-2 text-center">
                    <p className="text-xs text-blue-600 font-medium">NIRF Rank</p>
                    <p className="text-lg font-bold text-blue-800">#{university.nirfRank}</p>
                  </div>
                )}
                {university.qsRank && (
                  <div className="rounded-lg bg-purple-50 px-3 py-2 text-center">
                    <p className="text-xs text-purple-600 font-medium">QS Rank</p>
                    <p className="text-lg font-bold text-purple-800">#{university.qsRank}</p>
                  </div>
                )}
                {university.theRank && (
                  <div className="rounded-lg bg-indigo-50 px-3 py-2 text-center">
                    <p className="text-xs text-indigo-600 font-medium">THE Rank</p>
                    <p className="text-lg font-bold text-indigo-800">#{university.theRank}</p>
                  </div>
                )}
                {university.naacGrade !== "NOT_ACCREDITED" && (
                  <div className="rounded-lg bg-green-50 px-3 py-2 text-center">
                    <p className="text-xs text-green-600 font-medium">NAAC</p>
                    <p className="text-lg font-bold text-green-800">
                      {getNaacLabel(university.naacGrade)}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Apply CTA */}
            <div className="shrink-0">
              <a
                href="#apply"
                className="inline-flex items-center rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-white hover:bg-primary/90 transition-colors"
              >
                Apply Now
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 grid gap-8 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Overview */}
            <section className="rounded-xl border bg-white p-6">
              <h2 className="text-lg font-semibold text-gray-900">Overview</h2>
              <p className="mt-3 text-gray-600 leading-relaxed whitespace-pre-line">
                {university.description}
              </p>
              {university.website && (
                <a
                  href={university.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 inline-flex items-center gap-1 text-sm text-primary hover:underline"
                >
                  <Globe className="h-4 w-4" /> Visit Official Website
                  <ExternalLink className="h-3 w-3" />
                </a>
              )}
            </section>

            {/* Courses & Fees */}
            {university.courses.length > 0 && (
              <section className="rounded-xl border bg-white p-6">
                <h2 className="text-lg font-semibold text-gray-900">
                  Courses & Fees
                </h2>
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b text-left text-gray-500">
                        <th className="pb-3 font-medium">Course</th>
                        <th className="pb-3 font-medium">Level</th>
                        <th className="pb-3 font-medium">Duration</th>
                        <th className="pb-3 font-medium">Fees/Year</th>
                        <th className="pb-3 font-medium">Seats</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {university.courses.map((course) => (
                        <tr key={course.id} className="text-gray-700">
                          <td className="py-3 pr-4">
                            <div className="font-medium">{course.name}</div>
                            <div className="text-xs text-gray-400">
                              {course.category.name}
                            </div>
                          </td>
                          <td className="py-3">{course.degreeLevel}</td>
                          <td className="py-3">
                            {course.durationYears
                              ? `${course.durationYears} years`
                              : "—"}
                          </td>
                          <td className="py-3">
                            {course.feesPerYear
                              ? formatCurrency(Number(course.feesPerYear))
                              : "—"}
                          </td>
                          <td className="py-3">{course.seats ?? "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            )}

            {/* Placements */}
            {(university.avgPlacementLpa || university.placementRate) && (
              <section className="rounded-xl border bg-white p-6">
                <h2 className="flex items-center gap-2 text-lg font-semibold text-gray-900">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  Placements
                </h2>
                <div className="mt-4 grid grid-cols-3 gap-4">
                  {university.avgPlacementLpa && (
                    <div className="rounded-lg bg-gray-50 p-4 text-center">
                      <p className="text-2xl font-bold text-gray-900">
                        {Number(university.avgPlacementLpa)} LPA
                      </p>
                      <p className="text-xs text-gray-500">Average Package</p>
                    </div>
                  )}
                  {university.highestPlacementLpa && (
                    <div className="rounded-lg bg-gray-50 p-4 text-center">
                      <p className="text-2xl font-bold text-gray-900">
                        {Number(university.highestPlacementLpa)} LPA
                      </p>
                      <p className="text-xs text-gray-500">Highest Package</p>
                    </div>
                  )}
                  {university.placementRate && (
                    <div className="rounded-lg bg-gray-50 p-4 text-center">
                      <p className="text-2xl font-bold text-gray-900">
                        {Number(university.placementRate)}%
                      </p>
                      <p className="text-xs text-gray-500">Placement Rate</p>
                    </div>
                  )}
                </div>
              </section>
            )}

            {/* FAQs */}
            {university.faqs.length > 0 && (
              <section className="rounded-xl border bg-white p-6">
                <h2 className="text-lg font-semibold text-gray-900">
                  Frequently Asked Questions
                </h2>
                <div className="mt-4 divide-y">
                  {university.faqs.map((faq) => (
                    <details key={faq.id} className="group py-4">
                      <summary className="cursor-pointer text-sm font-medium text-gray-800 hover:text-primary">
                        {faq.question}
                      </summary>
                      <p className="mt-2 text-sm text-gray-600 leading-relaxed">
                        {faq.answer}
                      </p>
                    </details>
                  ))}
                </div>
              </section>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Info */}
            <div className="rounded-xl border bg-white p-6">
              <h3 className="text-sm font-semibold text-gray-900">
                Contact Information
              </h3>
              <div className="mt-3 space-y-3">
                {university.contactEmail && (
                  <a
                    href={`mailto:${university.contactEmail}`}
                    className="flex items-center gap-2 text-sm text-gray-600 hover:text-primary"
                  >
                    <Mail className="h-4 w-4" />
                    {university.contactEmail}
                  </a>
                )}
                {university.contactPhone && (
                  <a
                    href={`tel:${university.contactPhone}`}
                    className="flex items-center gap-2 text-sm text-gray-600 hover:text-primary"
                  >
                    <Phone className="h-4 w-4" />
                    {university.contactPhone}
                  </a>
                )}
                {university.address && (
                  <p className="flex items-start gap-2 text-sm text-gray-600">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0" />
                    {university.address}
                  </p>
                )}
              </div>
            </div>

            {/* Apply Form */}
            <div id="apply" className="rounded-xl border bg-white p-6">
              <h3 className="text-lg font-semibold text-gray-900">Apply Now</h3>
              <p className="mt-1 text-sm text-gray-500">
                Fill in your details and we&apos;ll connect you with the
                admissions team.
              </p>
              <div className="mt-4">
                <LeadForm
                  universityId={university.id}
                  universityName={university.name}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
