import { db } from "@/lib/db";
import { Breadcrumbs } from "@/components/layout/Breadcrumbs";
import { LeadForm } from "@/components/forms/LeadForm";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Apply Now — Get Counseling for Top Indian Universities",
  description:
    "Submit your details and get free expert counseling on university admissions, courses, and placements.",
};

export default async function ApplyPage() {
  const universities = await db.university.findMany({
    where: { status: "PUBLISHED" },
    select: { id: true, name: true },
    orderBy: { name: "asc" },
  });

  return (
    <div className="mx-auto max-w-2xl px-4 py-6 sm:px-6 lg:px-8">
      <Breadcrumbs items={[{ label: "Apply Now" }]} />

      <div className="mt-4 rounded-2xl border bg-white p-6 sm:p-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">
            Apply to Top Universities
          </h1>
          <p className="mt-2 text-sm text-gray-500">
            Fill in your details below and our expert counselors will guide you
            to the best university and course for your profile.
          </p>
        </div>

        <div className="mt-8">
          <LeadForm universities={universities} />
        </div>
      </div>
    </div>
  );
}
