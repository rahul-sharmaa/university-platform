import { db } from "@/lib/db";
import { notFound } from "next/navigation";
import { UniversityCard } from "@/components/university/UniversityCard";
import { Breadcrumbs } from "@/components/layout/Breadcrumbs";
import type { Metadata } from "next";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const state = await db.state.findUnique({ where: { slug } });
  if (!state) return { title: "State Not Found" };
  return {
    title: `Top Universities in ${state.name} — Rankings & Admissions`,
    description: `Explore the best universities in ${state.name}. Compare rankings, courses, fees, and apply directly.`,
  };
}

export async function generateStaticParams() {
  const states = await db.state.findMany({ select: { slug: true } });
  return states.map((s) => ({ slug: s.slug }));
}

export const revalidate = 300;

export default async function StatePage({ params }: PageProps) {
  const { slug } = await params;
  const state = await db.state.findUnique({
    where: { slug },
    include: {
      universities: {
        where: { status: "PUBLISHED" },
        include: {
          state: true,
          city: true,
          _count: { select: { courses: true } },
        },
        orderBy: { nirfRank: { sort: "asc", nulls: "last" } },
      },
    },
  });

  if (!state) notFound();

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      <Breadcrumbs
        items={[
          { label: "Universities", href: "/universities" },
          { label: state.name },
        ]}
      />

      <h1 className="mt-4 text-2xl font-bold text-gray-900">
        Top Universities in {state.name}
      </h1>
      <p className="mt-1 text-sm text-gray-500">
        {state.universities.length}{" "}
        {state.universities.length === 1 ? "university" : "universities"} found
      </p>

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {state.universities.map((uni) => (
          <UniversityCard key={uni.id} university={uni as any} />
        ))}
      </div>

      {state.universities.length === 0 && (
        <div className="mt-8 rounded-xl border bg-gray-50 py-16 text-center text-gray-500">
          No universities found in {state.name} yet.
        </div>
      )}
    </div>
  );
}
