import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { getNaacLabel, getUniversityTypeLabel } from "@/lib/utils";
import Link from "next/link";
import { Plus, Pencil, Eye } from "lucide-react";

export default async function AdminUniversitiesPage() {
  const session = await auth();
  if (!session?.user) redirect("/auth/signin");

  const user = session.user as any;
  const isSuper = user.role === "SUPER_ADMIN";

  const where = isSuper ? {} : { id: user.universityId };

  const universities = await db.university.findMany({
    where,
    include: {
      state: { select: { name: true } },
      city: { select: { name: true } },
      _count: { select: { leads: true, courses: true } },
    },
    orderBy: { updatedAt: "desc" },
  });

  return (
    <AdminLayout user={{ name: user.name || "", email: user.email || "", role: user.role }}>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Universities</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage university listings
          </p>
        </div>
        {isSuper && (
          <Link
            href="/admin/universities/new"
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white hover:bg-primary/90"
          >
            <Plus className="h-4 w-4" />
            Add University
          </Link>
        )}
      </div>

      <div className="mt-6 overflow-hidden rounded-xl border bg-white">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-gray-50 text-left text-gray-500">
              <th className="px-4 py-3 font-medium">University</th>
              <th className="px-4 py-3 font-medium">Location</th>
              <th className="px-4 py-3 font-medium">Type</th>
              <th className="px-4 py-3 font-medium">NAAC</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Leads</th>
              <th className="px-4 py-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {universities.map((uni) => (
              <tr key={uni.id} className="hover:bg-gray-50">
                <td className="px-4 py-3">
                  <div className="font-medium text-gray-900">{uni.name}</div>
                  <div className="text-xs text-gray-400">{uni.slug}</div>
                </td>
                <td className="px-4 py-3 text-gray-600">
                  {uni.city.name}, {uni.state.name}
                </td>
                <td className="px-4 py-3 text-gray-600">
                  {getUniversityTypeLabel(uni.universityType)}
                </td>
                <td className="px-4 py-3">
                  <span className="rounded-md bg-purple-50 px-2 py-0.5 text-xs font-medium text-purple-700">
                    {getNaacLabel(uni.naacGrade)}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                      uni.status === "PUBLISHED"
                        ? "bg-green-100 text-green-700"
                        : uni.status === "DRAFT"
                          ? "bg-gray-100 text-gray-600"
                          : uni.status === "PENDING_REVIEW"
                            ? "bg-yellow-100 text-yellow-700"
                            : "bg-red-100 text-red-700"
                    }`}
                  >
                    {uni.status.replace("_", " ")}
                  </span>
                </td>
                <td className="px-4 py-3 text-gray-600">
                  {uni._count.leads}
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Link
                      href={`/admin/universities/${uni.id}/edit`}
                      className="rounded-md p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
                      title="Edit"
                    >
                      <Pencil className="h-4 w-4" />
                    </Link>
                    <Link
                      href={`/universities/${uni.slug}`}
                      target="_blank"
                      className="rounded-md p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
                      title="View public page"
                    >
                      <Eye className="h-4 w-4" />
                    </Link>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
