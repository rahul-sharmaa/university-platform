import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { AdminLayout } from "@/components/admin/AdminLayout";
import Link from "next/link";

interface PageProps {
  searchParams: Promise<{ [key: string]: string | undefined }>;
}

export default async function AdminLeadsPage({ searchParams }: PageProps) {
  const session = await auth();
  if (!session?.user) redirect("/auth/signin");

  const user = session.user as any;
  const isSuper = user.role === "SUPER_ADMIN";
  const params = await searchParams;
  const statusFilter = params.status;

  const where = {
    ...(isSuper ? {} : { universityId: user.universityId }),
    ...(statusFilter && { status: statusFilter as any }),
  };

  const leads = await db.lead.findMany({
    where,
    include: {
      university: { select: { name: true, slug: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  const statusCounts = await db.lead.groupBy({
    by: ["status"],
    where: isSuper ? {} : { universityId: user.universityId },
    _count: true,
  });

  return (
    <AdminLayout user={{ name: user.name || "", email: user.email || "", role: user.role }}>
      <h1 className="text-2xl font-bold text-gray-900">Leads</h1>
      <p className="mt-1 text-sm text-gray-500">
        Manage and track incoming applications
      </p>

      {/* Status filter tabs */}
      <div className="mt-4 flex gap-2">
        <Link
          href="/admin/leads"
          className={`rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
            !statusFilter
              ? "bg-primary/10 text-primary"
              : "text-gray-500 hover:bg-gray-100"
          }`}
        >
          All
        </Link>
        {["NEW", "CONTACTED", "QUALIFIED", "CONVERTED", "CLOSED"].map(
          (status) => {
            const count =
              statusCounts.find((s) => s.status === status)?._count || 0;
            return (
              <Link
                key={status}
                href={`/admin/leads?status=${status}`}
                className={`rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
                  statusFilter === status
                    ? "bg-primary/10 text-primary"
                    : "text-gray-500 hover:bg-gray-100"
                }`}
              >
                {status.charAt(0) + status.slice(1).toLowerCase()} ({count})
              </Link>
            );
          }
        )}
      </div>

      <div className="mt-6 overflow-hidden rounded-xl border bg-white">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-gray-50 text-left text-gray-500">
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Contact</th>
              <th className="px-4 py-3 font-medium">Course</th>
              <th className="px-4 py-3 font-medium">University</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Date</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {leads.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-4 py-12 text-center text-gray-400">
                  No leads found
                </td>
              </tr>
            ) : (
              leads.map((lead) => (
                <tr key={lead.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium text-gray-900">
                    {lead.name}
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-gray-600">{lead.email}</div>
                    <div className="text-xs text-gray-400">{lead.phone}</div>
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {lead.interestedCourse || "—"}
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {lead.university?.name || "—"}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        lead.status === "NEW"
                          ? "bg-blue-100 text-blue-700"
                          : lead.status === "CONTACTED"
                            ? "bg-yellow-100 text-yellow-700"
                            : lead.status === "CONVERTED"
                              ? "bg-green-100 text-green-700"
                              : lead.status === "CLOSED"
                                ? "bg-red-100 text-red-700"
                                : "bg-gray-100 text-gray-600"
                      }`}
                    >
                      {lead.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-gray-500">
                    {lead.createdAt.toLocaleDateString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
