import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { AdminLayout } from "@/components/admin/AdminLayout";
import {
  GraduationCap,
  FileText,
  TrendingUp,
  Clock,
  AlertCircle,
} from "lucide-react";
import Link from "next/link";

export default async function AdminDashboard() {
  const session = await auth();
  if (!session?.user) redirect("/auth/signin");

  const user = session.user as any;
  const isSuper = user.role === "SUPER_ADMIN";

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const uniWhere = isSuper ? {} : { id: user.universityId };
  const leadWhere = isSuper ? {} : { universityId: user.universityId };

  const [totalUni, publishedUni, totalLeads, todayLeads, pendingRevisions, recentLeads] =
    await Promise.all([
      db.university.count({ where: uniWhere }),
      db.university.count({ where: { ...uniWhere, status: "PUBLISHED" } }),
      db.lead.count({ where: leadWhere }),
      db.lead.count({ where: { ...leadWhere, createdAt: { gte: today } } }),
      isSuper ? db.universityRevision.count({ where: { status: "PENDING" } }) : 0,
      db.lead.findMany({
        where: leadWhere,
        include: { university: { select: { name: true } } },
        orderBy: { createdAt: "desc" },
        take: 5,
      }),
    ]);

  const stats = [
    {
      label: "Total Universities",
      value: totalUni,
      icon: GraduationCap,
      color: "text-blue-600 bg-blue-50",
    },
    {
      label: "Published",
      value: publishedUni,
      icon: TrendingUp,
      color: "text-green-600 bg-green-50",
    },
    {
      label: "Total Leads",
      value: totalLeads,
      icon: FileText,
      color: "text-purple-600 bg-purple-50",
    },
    {
      label: "Leads Today",
      value: todayLeads,
      icon: Clock,
      color: "text-amber-600 bg-amber-50",
    },
  ];

  return (
    <AdminLayout user={{ name: user.name || "", email: user.email || "", role: user.role }}>
      <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
      <p className="mt-1 text-sm text-gray-500">
        Welcome back, {user.name}.
      </p>

      {/* Stats grid */}
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="rounded-xl border bg-white p-5"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-lg ${stat.color}`}
                >
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">
                    {stat.value}
                  </p>
                  <p className="text-xs text-gray-500">{stat.label}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Pending revisions alert */}
      {isSuper && pendingRevisions > 0 && (
        <div className="mt-6 flex items-center gap-3 rounded-lg bg-amber-50 border border-amber-200 p-4">
          <AlertCircle className="h-5 w-5 text-amber-600" />
          <div className="flex-1">
            <p className="text-sm font-medium text-amber-800">
              {pendingRevisions} pending{" "}
              {pendingRevisions === 1 ? "revision" : "revisions"} awaiting
              your review.
            </p>
          </div>
          <Link
            href="/admin/revisions"
            className="text-sm font-semibold text-amber-700 hover:underline"
          >
            Review now
          </Link>
        </div>
      )}

      {/* Recent leads */}
      <div className="mt-8">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Recent Leads</h2>
          <Link
            href="/admin/leads"
            className="text-sm font-semibold text-primary hover:underline"
          >
            View all
          </Link>
        </div>

        <div className="mt-4 overflow-hidden rounded-xl border bg-white">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-gray-50 text-left text-gray-500">
                <th className="px-4 py-3 font-medium">Name</th>
                <th className="px-4 py-3 font-medium">Email</th>
                <th className="px-4 py-3 font-medium">Phone</th>
                <th className="px-4 py-3 font-medium">University</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {recentLeads.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-gray-400">
                    No leads yet
                  </td>
                </tr>
              ) : (
                recentLeads.map((lead) => (
                  <tr key={lead.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">
                      {lead.name}
                    </td>
                    <td className="px-4 py-3 text-gray-600">{lead.email}</td>
                    <td className="px-4 py-3 text-gray-600">{lead.phone}</td>
                    <td className="px-4 py-3 text-gray-600">
                      {lead.university?.name || "—"}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                          lead.status === "NEW"
                            ? "bg-blue-100 text-blue-700"
                            : lead.status === "CONTACTED"
                              ? "bg-yellow-100 text-yellow-700"
                              : lead.status === "CONVERTED"
                                ? "bg-green-100 text-green-700"
                                : "bg-gray-100 text-gray-600"
                        }`}
                      >
                        {lead.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-500">
                      {lead.createdAt.toLocaleDateString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
