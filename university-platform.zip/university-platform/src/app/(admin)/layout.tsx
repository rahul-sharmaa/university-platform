import type { Metadata } from "next";

export const metadata: Metadata = {
  title: {
    default: "Admin Panel | UniRank India",
    template: "%s | Admin | UniRank India",
  },
  robots: { index: false, follow: false },
};

export default function AdminRootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
