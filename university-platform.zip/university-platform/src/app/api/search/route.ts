import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const q = request.nextUrl.searchParams.get("q");

    if (!q || q.length < 2) {
      return NextResponse.json({ results: [] });
    }

    const universities = await db.university.findMany({
      where: {
        status: "PUBLISHED",
        OR: [
          { name: { contains: q, mode: "insensitive" } },
          { shortName: { contains: q, mode: "insensitive" } },
          { city: { name: { contains: q, mode: "insensitive" } } },
          { state: { name: { contains: q, mode: "insensitive" } } },
        ],
      },
      select: {
        id: true,
        name: true,
        slug: true,
        shortName: true,
        nirfRank: true,
        city: { select: { name: true } },
        state: { select: { name: true } },
      },
      take: 10,
      orderBy: { nirfRank: { sort: "asc", nulls: "last" } },
    });

    return NextResponse.json({ results: universities });
  } catch (error) {
    console.error("Search error:", error);
    return NextResponse.json(
      { error: "Search failed" },
      { status: 500 }
    );
  }
}
