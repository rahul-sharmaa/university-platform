import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { leadFormSchema } from "@/lib/validation/lead";

// Rate limiting: simple in-memory store (use Redis in production)
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const windowMs = 60 * 1000; // 1 minute
  const maxRequests = 5;

  const entry = rateLimitMap.get(ip);
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + windowMs });
    return true;
  }

  if (entry.count >= maxRequests) return false;
  entry.count++;
  return true;
}

export async function POST(request: NextRequest) {
  try {
    // Rate limiting
    const ip =
      request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      "unknown";
    if (!checkRateLimit(ip)) {
      return NextResponse.json(
        { error: "Too many requests. Please try again in a minute." },
        { status: 429 }
      );
    }

    const body = await request.json();
    const parsed = leadFormSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { name, email, phone, interestedCourse, universityId, state, city, message } = parsed.data;

    // Verify university exists if provided
    if (universityId) {
      const university = await db.university.findUnique({
        where: { id: universityId },
        select: { id: true },
      });
      if (!university) {
        return NextResponse.json(
          { error: "Invalid university ID" },
          { status: 400 }
        );
      }
    }

    const lead = await db.lead.create({
      data: {
        name,
        email,
        phone,
        interestedCourse,
        universityId: universityId || null,
        state,
        city,
        message,
        sourcePage: request.headers.get("referer") || null,
        utmSource: request.nextUrl.searchParams.get("utm_source") || null,
        utmMedium: request.nextUrl.searchParams.get("utm_medium") || null,
        utmCampaign: request.nextUrl.searchParams.get("utm_campaign") || null,
        ipAddress: ip,
        userAgent: request.headers.get("user-agent") || null,
      },
    });

    // TODO: Send email notification to university admin
    // TODO: Send confirmation email to lead

    return NextResponse.json(
      { success: true, id: lead.id },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error creating lead:", error);
    return NextResponse.json(
      { error: "Failed to submit application. Please try again." },
      { status: 500 }
    );
  }
}
