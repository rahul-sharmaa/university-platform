import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getNaacLabel, getUniversityTypeLabel } from "@/lib/utils";

export async function GET() {
  try {
    const [states, courseCategories, universityTypes, naacGrades] =
      await Promise.all([
        db.state.findMany({
          where: { universities: { some: { status: "PUBLISHED" } } },
          include: {
            _count: {
              select: { universities: { where: { status: "PUBLISHED" } } },
            },
          },
          orderBy: { name: "asc" },
        }),
        db.courseCategory.findMany({
          include: {
            _count: {
              select: {
                courses: {
                  where: { university: { status: "PUBLISHED" }, isActive: true },
                },
              },
            },
          },
          orderBy: { name: "asc" },
        }),
        db.university.groupBy({
          by: ["universityType"],
          where: { status: "PUBLISHED" },
          _count: true,
        }),
        db.university.groupBy({
          by: ["naacGrade"],
          where: { status: "PUBLISHED", naacGrade: { not: "NOT_ACCREDITED" } },
          _count: true,
          orderBy: { naacGrade: "asc" },
        }),
      ]);

    return NextResponse.json({
      states: states.map((s) => ({
        slug: s.slug,
        name: s.name,
        count: s._count.universities,
      })),
      courseCategories: courseCategories
        .filter((c) => c._count.courses > 0)
        .map((c) => ({
          slug: c.slug,
          name: c.name,
          count: c._count.courses,
        })),
      universityTypes: universityTypes.map((t) => ({
        value: t.universityType,
        label: getUniversityTypeLabel(t.universityType),
        count: t._count,
      })),
      naacGrades: naacGrades.map((g) => ({
        value: g.naacGrade,
        label: `NAAC ${getNaacLabel(g.naacGrade)}`,
        count: g._count,
      })),
    });
  } catch (error) {
    console.error("Error fetching filter options:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
