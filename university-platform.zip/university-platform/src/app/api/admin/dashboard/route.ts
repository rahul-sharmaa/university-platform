import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const user = session.user as any;
    const isSuper = user.role === "SUPER_ADMIN";

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const universityWhere = isSuper ? {} : { id: user.universityId };
    const leadWhere = isSuper
      ? {}
      : { universityId: user.universityId };

    const [
      totalUniversities,
      publishedUniversities,
      totalLeads,
      newLeadsToday,
      pendingRevisions,
      recentLeads,
    ] = await Promise.all([
      db.university.count({ where: universityWhere }),
      db.university.count({ where: { ...universityWhere, status: "PUBLISHED" } }),
      db.lead.count({ where: leadWhere }),
      db.lead.count({ where: { ...leadWhere, createdAt: { gte: today } } }),
      isSuper
        ? db.universityRevision.count({ where: { status: "PENDING" } })
        : 0,
      db.lead.findMany({
        where: leadWhere,
        include: { university: { select: { name: true } } },
        orderBy: { createdAt: "desc" },
        take: 10,
      }),
    ]);

    return NextResponse.json({
      stats: {
        totalUniversities,
        publishedUniversities,
        totalLeads,
        newLeadsToday,
        pendingRevisions,
      },
      recentLeads,
    });
  } catch (error) {
    console.error("Dashboard error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
