import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const user = session.user as any;
    if (user.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const status = request.nextUrl.searchParams.get("status") || "PENDING";

    const revisions = await db.universityRevision.findMany({
      where: { status: status as any },
      include: {
        university: { select: { id: true, name: true, slug: true } },
        submittedBy: { select: { id: true, name: true, email: true } },
        reviewedBy: { select: { id: true, name: true } },
      },
      orderBy: { submittedAt: "desc" },
    });

    return NextResponse.json(revisions);
  } catch (error) {
    console.error("Revisions error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
