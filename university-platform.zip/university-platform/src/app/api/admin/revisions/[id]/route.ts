import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { createAuditLog } from "@/lib/utils/audit";
import { z } from "zod";

const reviewSchema = z.object({
  action: z.enum(["approve", "reject"]),
  comment: z.string().max(1000).optional(),
});

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const user = session.user as any;
    if (user.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { id } = await params;
    const body = await request.json();
    const parsed = reviewSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const revision = await db.universityRevision.findUnique({
      where: { id },
    });

    if (!revision || revision.status !== "PENDING") {
      return NextResponse.json(
        { error: "Revision not found or already reviewed" },
        { status: 404 }
      );
    }

    if (parsed.data.action === "approve") {
      // Apply changes to university
      await db.university.update({
        where: { id: revision.universityId },
        data: {
          ...(revision.data as object),
          updatedById: user.id,
        },
      });

      await db.universityRevision.update({
        where: { id },
        data: {
          status: "APPROVED",
          reviewedById: user.id,
          reviewerComment: parsed.data.comment,
          reviewedAt: new Date(),
        },
      });

      await createAuditLog({
        userId: user.id,
        entityType: "university_revision",
        entityId: id,
        action: "approve",
      });
    } else {
      await db.universityRevision.update({
        where: { id },
        data: {
          status: "REJECTED",
          reviewedById: user.id,
          reviewerComment: parsed.data.comment,
          reviewedAt: new Date(),
        },
      });

      await createAuditLog({
        userId: user.id,
        entityType: "university_revision",
        entityId: id,
        action: "reject",
      });
    }

    return NextResponse.json({ success: true, action: parsed.data.action });
  } catch (error) {
    console.error("Review revision error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
