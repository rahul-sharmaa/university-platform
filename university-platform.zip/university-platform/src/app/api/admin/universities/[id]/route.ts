import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { universityCreateSchema } from "@/lib/validation/university";
import { createAuditLog, computeDiff } from "@/lib/utils/audit";
import { hasPermission } from "@/lib/auth/permissions";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const user = session.user as any;
    const isSuper = user.role === "SUPER_ADMIN";

    if (!isSuper && user.universityId !== id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const university = await db.university.findUnique({
      where: { id },
      include: {
        state: true,
        city: true,
        courses: { include: { category: true } },
        faqs: { orderBy: { sortOrder: "asc" } },
      },
    });

    if (!university) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    return NextResponse.json(university);
  } catch (error) {
    console.error("Admin university GET error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const user = session.user as any;
    const isSuper = user.role === "SUPER_ADMIN";

    if (!isSuper && user.universityId !== id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const existing = await db.university.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    const body = await request.json();
    const parsed = universityCreateSchema.partial().safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    // For university admins, certain fields require approval
    const protectedFields = [
      "name", "description", "nirfRank", "qsRank", "theRank",
      "naacGrade", "nbaStatus", "feesMin", "feesMax",
      "avgPlacementLpa", "highestPlacementLpa", "placementRate",
    ];

    const hasProtectedChanges =
      !isSuper &&
      Object.keys(parsed.data).some((key) => protectedFields.includes(key));

    if (hasProtectedChanges) {
      // Create revision for approval
      const revision = await db.universityRevision.create({
        data: {
          universityId: id,
          submittedById: user.id,
          data: parsed.data as any,
          diff: computeDiff(existing as any, parsed.data as any) as any,
          status: "PENDING",
        },
      });

      await createAuditLog({
        userId: user.id,
        entityType: "university_revision",
        entityId: revision.id,
        action: "create",
        changes: computeDiff(existing as any, parsed.data as any),
      });

      return NextResponse.json({
        message: "Changes submitted for review",
        revisionId: revision.id,
      });
    }

    // Apply changes directly
    const updated = await db.university.update({
      where: { id },
      data: {
        ...parsed.data,
        updatedById: user.id,
      },
    });

    await createAuditLog({
      userId: user.id,
      entityType: "university",
      entityId: id,
      action: "update",
      changes: computeDiff(existing as any, parsed.data as any),
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Update university error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const user = session.user as any;

    if (!hasPermission(user.role, "university:delete")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    await db.university.update({
      where: { id },
      data: { status: "ARCHIVED", updatedById: user.id },
    });

    await createAuditLog({
      userId: user.id,
      entityType: "university",
      entityId: id,
      action: "archive",
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete university error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
