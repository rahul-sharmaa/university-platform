import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { universityCreateSchema } from "@/lib/validation/university";
import { createAuditLog } from "@/lib/utils/audit";
import { hasPermission } from "@/lib/auth/permissions";

export async function GET(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const user = session.user as any;
    const isSuper = user.role === "SUPER_ADMIN";

    const page = Number(request.nextUrl.searchParams.get("page")) || 1;
    const limit = Number(request.nextUrl.searchParams.get("limit")) || 20;
    const skip = (page - 1) * limit;

    const where = isSuper ? {} : { id: user.universityId };

    const [data, total] = await Promise.all([
      db.university.findMany({
        where,
        include: {
          state: { select: { name: true } },
          city: { select: { name: true } },
          _count: { select: { leads: true, courses: true } },
        },
        orderBy: { updatedAt: "desc" },
        skip,
        take: limit,
      }),
      db.university.count({ where }),
    ]);

    return NextResponse.json({
      data,
      meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error("Admin universities error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const user = session.user as any;
    if (!hasPermission(user.role, "university:create")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const parsed = universityCreateSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const university = await db.university.create({
      data: {
        ...parsed.data,
        createdById: user.id,
        updatedById: user.id,
      },
    });

    await createAuditLog({
      userId: user.id,
      entityType: "university",
      entityId: university.id,
      action: "create",
    });

    return NextResponse.json(university, { status: 201 });
  } catch (error: any) {
    if (error?.code === "P2002") {
      return NextResponse.json(
        { error: "A university with this slug already exists" },
        { status: 409 }
      );
    }
    console.error("Create university error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
