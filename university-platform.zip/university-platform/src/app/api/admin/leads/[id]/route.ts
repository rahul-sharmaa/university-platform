import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { createAuditLog } from "@/lib/utils/audit";
import { z } from "zod";

const updateLeadSchema = z.object({
  status: z.enum(["NEW", "CONTACTED", "QUALIFIED", "CONVERTED", "CLOSED"]).optional(),
  notes: z.string().max(2000).optional(),
  assignedToId: z.string().optional(),
});

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const user = session.user as any;
    const isSuper = user.role === "SUPER_ADMIN";

    const lead = await db.lead.findUnique({ where: { id } });
    if (!lead) {
      return NextResponse.json({ error: "Lead not found" }, { status: 404 });
    }

    if (!isSuper && lead.universityId !== user.universityId) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const parsed = updateLeadSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const updated = await db.lead.update({
      where: { id },
      data: {
        ...parsed.data,
        ...(parsed.data.status === "CONTACTED" && !lead.contactedAt
          ? { contactedAt: new Date() }
          : {}),
      },
    });

    await createAuditLog({
      userId: user.id,
      entityType: "lead",
      entityId: id,
      action: "update",
      changes: parsed.data as any,
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Update lead error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
