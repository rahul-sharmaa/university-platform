import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const user = session.user as any;
    const isSuper = user.role === "SUPER_ADMIN";

    const page = Number(request.nextUrl.searchParams.get("page")) || 1;
    const limit = Number(request.nextUrl.searchParams.get("limit")) || 20;
    const status = request.nextUrl.searchParams.get("status") || undefined;
    const skip = (page - 1) * limit;

    const where = {
      ...(isSuper ? {} : { universityId: user.universityId }),
      ...(status && { status: status as any }),
    };

    const [data, total] = await Promise.all([
      db.lead.findMany({
        where,
        include: {
          university: { select: { id: true, name: true, slug: true } },
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
      }),
      db.lead.count({ where }),
    ]);

    return NextResponse.json({
      data,
      meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error("Admin leads error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
