import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { universityFilterSchema } from "@/lib/validation/university";
import type { Prisma } from "@prisma/client";

export async function GET(request: NextRequest) {
  try {
    const searchParams = Object.fromEntries(request.nextUrl.searchParams);
    const parsed = universityFilterSchema.safeParse(searchParams);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid query parameters", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { page, limit, sort, order, state, city, courseCategory, universityType, naacGrade, nbaStatus, feesMin, feesMax, establishedBefore, q } = parsed.data;

    const skip = (page - 1) * limit;

    // Build where clause
    const where: Prisma.UniversityWhereInput = {
      status: "PUBLISHED",
      ...(state && { state: { slug: state } }),
      ...(city && { city: { slug: city } }),
      ...(universityType && { universityType }),
      ...(naacGrade && { naacGrade: naacGrade as any }),
      ...(nbaStatus && { nbaStatus }),
      ...(feesMin && { feesMax: { gte: feesMin } }),
      ...(feesMax && { feesMin: { lte: feesMax } }),
      ...(establishedBefore && { establishedYear: { lte: establishedBefore } }),
      ...(courseCategory && {
        courses: { some: { category: { slug: courseCategory } } },
      }),
      ...(q && {
        OR: [
          { name: { contains: q, mode: "insensitive" as const } },
          { shortName: { contains: q, mode: "insensitive" as const } },
          { description: { contains: q, mode: "insensitive" as const } },
        ],
      }),
    };

    // Build sort
    const sortMap: Record<string, Prisma.UniversityOrderByWithRelationInput> = {
      nirf_rank: { nirfRank: { sort: order, nulls: "last" } },
      qs_rank: { qsRank: { sort: order, nulls: "last" } },
      the_rank: { theRank: { sort: order, nulls: "last" } },
      name: { name: order },
      established_year: { establishedYear: { sort: order, nulls: "last" } },
      fees_min: { feesMin: { sort: order, nulls: "last" } },
    };
    const orderBy = sortMap[sort] || sortMap.nirf_rank;

    const [data, total] = await Promise.all([
      db.university.findMany({
        where,
        include: {
          state: { select: { name: true, slug: true } },
          city: { select: { name: true, slug: true } },
          _count: { select: { courses: true } },
        },
        orderBy,
        skip,
        take: limit,
      }),
      db.university.count({ where }),
    ]);

    return NextResponse.json({
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error("Error fetching universities:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
