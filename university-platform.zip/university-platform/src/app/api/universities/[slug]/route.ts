import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;

    const university = await db.university.findUnique({
      where: { slug, status: "PUBLISHED" },
      include: {
        state: true,
        city: true,
        courses: {
          include: { category: true },
          where: { isActive: true },
          orderBy: { name: "asc" },
        },
        faqs: {
          where: { isActive: true },
          orderBy: { sortOrder: "asc" },
        },
        rankings: {
          include: { rankingSystem: true },
          orderBy: [{ year: "desc" }],
        },
      },
    });

    if (!university) {
      return NextResponse.json(
        { error: "University not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(university);
  } catch (error) {
    console.error("Error fetching university:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
