import type { University, State, City, Course, CourseCategory, UniversityFaq, Lead } from "@prisma/client";

// Extended university with relations for listing/detail pages
export type UniversityWithRelations = University & {
  state: State;
  city: City;
  courses?: (Course & { category: CourseCategory })[];
  faqs?: UniversityFaq[];
};

// Slimmed down for cards
export type UniversityCard = Pick<
  University,
  | "id"
  | "name"
  | "slug"
  | "shortName"
  | "logoUrl"
  | "universityType"
  | "nirfRank"
  | "qsRank"
  | "theRank"
  | "naacGrade"
  | "nbaStatus"
  | "feesMin"
  | "feesMax"
  | "establishedYear"
  | "isFeatured"
  | "isTrending"
> & {
  state: Pick<State, "name" | "slug">;
  city: Pick<City, "name" | "slug">;
  _count?: { courses: number };
};

// Paginated response
export interface PaginatedResponse<T> {
  data: T[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

// Filter options for sidebar
export interface FilterOptions {
  states: { slug: string; name: string; count: number }[];
  cities: { slug: string; name: string; count: number }[];
  courseCategories: { slug: string; name: string; count: number }[];
  universityTypes: { value: string; label: string; count: number }[];
  naacGrades: { value: string; label: string; count: number }[];
}

// Session user with role info
export interface SessionUser {
  id: string;
  name: string;
  email: string;
  role: "SUPER_ADMIN" | "UNIVERSITY_ADMIN";
  universityId?: string | null;
}

// Dashboard stats
export interface DashboardStats {
  totalUniversities: number;
  publishedUniversities: number;
  totalLeads: number;
  newLeadsToday: number;
  pendingRevisions: number;
}
