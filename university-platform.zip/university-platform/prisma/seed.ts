import { PrismaClient, UserRole, UniversityStatus, UniversityType, NaacGrade, NbaStatus } from "@prisma/client";
import { hash } from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding database...");

  // ─── States & Cities ────────────────────────────────
  const maharashtra = await prisma.state.upsert({
    where: { slug: "maharashtra" },
    update: {},
    create: { name: "Maharashtra", slug: "maharashtra", code: "MH" },
  });

  const karnataka = await prisma.state.upsert({
    where: { slug: "karnataka" },
    update: {},
    create: { name: "Karnataka", slug: "karnataka", code: "KA" },
  });

  const delhi = await prisma.state.upsert({
    where: { slug: "delhi" },
    update: {},
    create: { name: "Delhi", slug: "delhi", code: "DL" },
  });

  const tamilNadu = await prisma.state.upsert({
    where: { slug: "tamil-nadu" },
    update: {},
    create: { name: "Tamil Nadu", slug: "tamil-nadu", code: "TN" },
  });

  const westBengal = await prisma.state.upsert({
    where: { slug: "west-bengal" },
    update: {},
    create: { name: "West Bengal", slug: "west-bengal", code: "WB" },
  });

  const mumbai = await prisma.city.upsert({
    where: { slug_stateId: { slug: "mumbai", stateId: maharashtra.id } },
    update: {},
    create: { name: "Mumbai", slug: "mumbai", stateId: maharashtra.id },
  });

  const bangalore = await prisma.city.upsert({
    where: { slug_stateId: { slug: "bangalore", stateId: karnataka.id } },
    update: {},
    create: { name: "Bangalore", slug: "bangalore", stateId: karnataka.id },
  });

  const newDelhi = await prisma.city.upsert({
    where: { slug_stateId: { slug: "new-delhi", stateId: delhi.id } },
    update: {},
    create: { name: "New Delhi", slug: "new-delhi", stateId: delhi.id },
  });

  const chennai = await prisma.city.upsert({
    where: { slug_stateId: { slug: "chennai", stateId: tamilNadu.id } },
    update: {},
    create: { name: "Chennai", slug: "chennai", stateId: tamilNadu.id },
  });

  const kharagpur = await prisma.city.upsert({
    where: { slug_stateId: { slug: "kharagpur", stateId: westBengal.id } },
    update: {},
    create: { name: "Kharagpur", slug: "kharagpur", stateId: westBengal.id },
  });

  // ─── Course Categories ──────────────────────────────
  const categories = await Promise.all(
    [
      { name: "Engineering", slug: "engineering" },
      { name: "Management", slug: "management" },
      { name: "Science", slug: "science" },
      { name: "Arts & Humanities", slug: "arts-humanities" },
      { name: "Medicine", slug: "medicine" },
      { name: "Law", slug: "law" },
      { name: "Design", slug: "design" },
    ].map((cat) =>
      prisma.courseCategory.upsert({
        where: { slug: cat.slug },
        update: {},
        create: cat,
      })
    )
  );

  const engineeringCat = categories.find((c) => c.slug === "engineering")!;
  const managementCat = categories.find((c) => c.slug === "management")!;
  const scienceCat = categories.find((c) => c.slug === "science")!;

  // ─── Ranking Systems ────────────────────────────────
  await Promise.all(
    [
      { name: "QS World University Rankings", slug: "qs" },
      { name: "Times Higher Education", slug: "the" },
      { name: "NIRF", slug: "nirf" },
    ].map((rs) =>
      prisma.rankingSystem.upsert({
        where: { slug: rs.slug },
        update: {},
        create: rs,
      })
    )
  );

  // ─── Super Admin User ──────────────────────────────
  const adminPassword = await hash("admin123", 12);
  await prisma.user.upsert({
    where: { email: "admin@unirank.in" },
    update: {},
    create: {
      email: "admin@unirank.in",
      passwordHash: adminPassword,
      name: "Super Admin",
      role: UserRole.SUPER_ADMIN,
    },
  });

  // ─── Universities ──────────────────────────────────
  const universities = [
    {
      name: "Indian Institute of Technology Bombay",
      slug: "iit-bombay",
      shortName: "IIT Bombay",
      stateId: maharashtra.id,
      cityId: mumbai.id,
      address: "Powai, Mumbai, Maharashtra 400076",
      description:
        "Indian Institute of Technology Bombay (IIT Bombay) is a public technical university located in Powai, Mumbai. Established in 1958, it is the second-oldest IIT and is recognized as an Institute of National Importance by the Government of India. IIT Bombay is consistently ranked among the top engineering institutions in India and Asia.",
      website: "https://www.iitb.ac.in",
      establishedYear: 1958,
      universityType: UniversityType.IIT,
      qsRank: 149,
      qsRankYear: 2025,
      theRank: 250,
      theRankYear: 2025,
      nirfRank: 3,
      nirfRankYear: 2024,
      nirfCategory: "Overall",
      naacGrade: NaacGrade.A_PLUS_PLUS,
      nbaStatus: NbaStatus.ACCREDITED,
      feesMin: 200000,
      feesMax: 300000,
      avgPlacementLpa: 21.82,
      highestPlacementLpa: 309.0,
      placementRate: 95.5,
      contactEmail: "registrar@iitb.ac.in",
      contactPhone: "+91-22-25722545",
      status: UniversityStatus.PUBLISHED,
      isFeatured: true,
      metaTitle: "IIT Bombay - Rankings, Courses, Fees & Admissions 2025",
      metaDescription:
        "IIT Bombay: NIRF Rank #3, QS Rank #149. Explore courses, fees, placements, and admissions at India's premier engineering institute in Mumbai.",
    },
    {
      name: "Indian Institute of Science",
      slug: "iisc-bangalore",
      shortName: "IISc",
      stateId: karnataka.id,
      cityId: bangalore.id,
      address: "CV Raman Road, Bangalore, Karnataka 560012",
      description:
        "The Indian Institute of Science (IISc) is a public, deemed university for research and higher education in Bangalore. Established in 1909 with support from Jamsetji Tata, it is the premier institute for advanced scientific and technological research and education in India.",
      website: "https://iisc.ac.in",
      establishedYear: 1909,
      universityType: UniversityType.DEEMED,
      qsRank: 211,
      qsRankYear: 2025,
      theRank: 150,
      theRankYear: 2025,
      nirfRank: 1,
      nirfRankYear: 2024,
      nirfCategory: "Overall",
      naacGrade: NaacGrade.A_PLUS_PLUS,
      nbaStatus: NbaStatus.ACCREDITED,
      feesMin: 35000,
      feesMax: 80000,
      avgPlacementLpa: 36.0,
      highestPlacementLpa: 120.0,
      placementRate: 85.0,
      contactEmail: "registrar@iisc.ac.in",
      contactPhone: "+91-80-22932004",
      status: UniversityStatus.PUBLISHED,
      isFeatured: true,
      isTrending: true,
      metaTitle: "IISc Bangalore - Rankings, Courses, Fees & Admissions 2025",
      metaDescription:
        "IISc Bangalore: NIRF Rank #1, QS Rank #211. India's top research university. Explore courses, fees, and admissions.",
    },
    {
      name: "Indian Institute of Technology Delhi",
      slug: "iit-delhi",
      shortName: "IIT Delhi",
      stateId: delhi.id,
      cityId: newDelhi.id,
      address: "Hauz Khas, New Delhi, Delhi 110016",
      description:
        "Indian Institute of Technology Delhi (IIT Delhi) is a public technical university located in Hauz Khas, New Delhi. Established in 1961, it is recognized as an Institute of National Importance and is one of the most prestigious engineering institutions in India.",
      website: "https://home.iitd.ac.in",
      establishedYear: 1961,
      universityType: UniversityType.IIT,
      qsRank: 150,
      qsRankYear: 2025,
      theRank: 200,
      theRankYear: 2025,
      nirfRank: 2,
      nirfRankYear: 2024,
      nirfCategory: "Overall",
      naacGrade: NaacGrade.A_PLUS_PLUS,
      nbaStatus: NbaStatus.ACCREDITED,
      feesMin: 210000,
      feesMax: 310000,
      avgPlacementLpa: 24.0,
      highestPlacementLpa: 270.0,
      placementRate: 93.0,
      contactEmail: "registrar@admin.iitd.ac.in",
      contactPhone: "+91-11-26591999",
      status: UniversityStatus.PUBLISHED,
      isFeatured: true,
      metaTitle: "IIT Delhi - Rankings, Courses, Fees & Admissions 2025",
      metaDescription:
        "IIT Delhi: NIRF Rank #2, QS Rank #150. Explore courses, fees, placements, and admissions at one of India's top engineering institutes.",
    },
    {
      name: "Indian Institute of Technology Madras",
      slug: "iit-madras",
      shortName: "IIT Madras",
      stateId: tamilNadu.id,
      cityId: chennai.id,
      address: "IIT P.O., Chennai, Tamil Nadu 600036",
      description:
        "Indian Institute of Technology Madras (IIT Madras) is a public technical university in Chennai. Established in 1959 with technical assistance from West Germany, it has been ranked the No. 1 engineering institution in India by NIRF for multiple consecutive years.",
      website: "https://www.iitm.ac.in",
      establishedYear: 1959,
      universityType: UniversityType.IIT,
      qsRank: 227,
      qsRankYear: 2025,
      theRank: 250,
      theRankYear: 2025,
      nirfRank: 1,
      nirfRankYear: 2024,
      nirfCategory: "Engineering",
      naacGrade: NaacGrade.A_PLUS_PLUS,
      nbaStatus: NbaStatus.ACCREDITED,
      feesMin: 200000,
      feesMax: 280000,
      avgPlacementLpa: 22.0,
      highestPlacementLpa: 180.0,
      placementRate: 96.0,
      contactEmail: "registrar@iitm.ac.in",
      contactPhone: "+91-44-22578000",
      status: UniversityStatus.PUBLISHED,
      isTrending: true,
      metaTitle: "IIT Madras - Rankings, Courses, Fees & Admissions 2025",
      metaDescription:
        "IIT Madras: NIRF #1 in Engineering. Explore courses, fees, and placements at India's top-ranked engineering institute in Chennai.",
    },
    {
      name: "Indian Institute of Technology Kharagpur",
      slug: "iit-kharagpur",
      shortName: "IIT KGP",
      stateId: westBengal.id,
      cityId: kharagpur.id,
      address: "Kharagpur, West Bengal 721302",
      description:
        "Indian Institute of Technology Kharagpur (IIT Kharagpur) is the oldest IIT, established in 1951. Located in Kharagpur, West Bengal, it has the largest campus of any IIT and offers a wide range of programs across engineering, science, management, and humanities.",
      website: "https://www.iitkgp.ac.in",
      establishedYear: 1951,
      universityType: UniversityType.IIT,
      qsRank: 271,
      qsRankYear: 2025,
      theRank: 350,
      theRankYear: 2025,
      nirfRank: 5,
      nirfRankYear: 2024,
      nirfCategory: "Overall",
      naacGrade: NaacGrade.A_PLUS,
      nbaStatus: NbaStatus.ACCREDITED,
      feesMin: 190000,
      feesMax: 290000,
      avgPlacementLpa: 18.5,
      highestPlacementLpa: 200.0,
      placementRate: 90.0,
      contactEmail: "registrar@adm.iitkgp.ac.in",
      contactPhone: "+91-3222-255221",
      status: UniversityStatus.PUBLISHED,
      metaTitle:
        "IIT Kharagpur - Rankings, Courses, Fees & Admissions 2025",
      metaDescription:
        "IIT Kharagpur: India's oldest IIT, NIRF Rank #5. Explore courses, fees, placements at IIT KGP.",
    },
  ];

  for (const uni of universities) {
    const created = await prisma.university.upsert({
      where: { slug: uni.slug },
      update: {},
      create: uni,
    });

    // Add sample courses
    const sampleCourses = [
      {
        name: "B.Tech Computer Science and Engineering",
        slug: "btech-cse",
        categoryId: engineeringCat.id,
        durationYears: 4.0,
        degreeLevel: "UG",
        feesPerYear: uni.feesMin,
        eligibility: "JEE Advanced qualified. 75% aggregate in PCM in Class XII.",
        seats: 120,
      },
      {
        name: "M.Tech Artificial Intelligence",
        slug: "mtech-ai",
        categoryId: engineeringCat.id,
        durationYears: 2.0,
        degreeLevel: "PG",
        feesPerYear: uni.feesMin ? Number(uni.feesMin) * 1.2 : null,
        eligibility: "GATE qualified. B.Tech/BE in relevant discipline.",
        seats: 30,
      },
      {
        name: "MBA",
        slug: "mba",
        categoryId: managementCat.id,
        durationYears: 2.0,
        degreeLevel: "PG",
        feesPerYear: uni.feesMax,
        eligibility: "CAT/GMAT score. Bachelor's degree with 60% aggregate.",
        seats: 60,
      },
      {
        name: "M.Sc Physics",
        slug: "msc-physics",
        categoryId: scienceCat.id,
        durationYears: 2.0,
        degreeLevel: "PG",
        feesPerYear: uni.feesMin ? Number(uni.feesMin) * 0.5 : null,
        eligibility: "JAM qualified. B.Sc in Physics with 60% aggregate.",
        seats: 40,
      },
    ];

    for (const course of sampleCourses) {
      await prisma.course.upsert({
        where: {
          universityId_slug: { universityId: created.id, slug: course.slug },
        },
        update: {},
        create: {
          ...course,
          universityId: created.id,
        },
      });
    }

    // Add sample FAQs
    const sampleFaqs = [
      {
        question: `What is the admission process for ${uni.shortName || uni.name}?`,
        answer: `Admission to ${uni.shortName || uni.name} is primarily through national-level entrance examinations such as JEE Advanced (for B.Tech), GATE (for M.Tech), CAT (for MBA), and JAM (for M.Sc). Specific eligibility criteria and cutoffs vary by program.`,
        sortOrder: 1,
      },
      {
        question: `What is the average placement package at ${uni.shortName || uni.name}?`,
        answer: `The average placement package at ${uni.shortName || uni.name} is approximately ${uni.avgPlacementLpa} LPA, with the highest package reaching ${uni.highestPlacementLpa} LPA. The placement rate is around ${uni.placementRate}%.`,
        sortOrder: 2,
      },
      {
        question: `What are the hostel facilities like at ${uni.shortName || uni.name}?`,
        answer: `${uni.shortName || uni.name} provides on-campus hostel accommodation for all students. The hostels are well-equipped with Wi-Fi, mess facilities, common rooms, and sports facilities.`,
        sortOrder: 3,
      },
    ];

    for (const faq of sampleFaqs) {
      await prisma.universityFaq.create({
        data: {
          ...faq,
          universityId: created.id,
        },
      });
    }
  }

  console.log("Seed complete!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
